javac src/main/java/*.java
java -cp src/main/java/ ConstructionTester
