import java.util.Scanner;

public class HowFarAway 
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
       double longitude, latitude;
        double theLongitude, theLatitude, distance;
      

        System.out.println("Enter the latitude of the starting location: ");
        latitude = in.nextDouble();
        System.out.println("Enter the longitude of the starting location:");
        longitude = in.nextDouble();
        System.out.println("Enter the latitude of the ending location:");
        theLatitude = in.nextDouble();
        System.out.println("Enter the longitude of the Ending location:");
        theLongitude = in.nextDouble();

        GeoLocation next = new GeoLocation(theLatitude, theLongitude);
        
       System.out.println(next.distanceForm(longitude, latitude));
    }
}