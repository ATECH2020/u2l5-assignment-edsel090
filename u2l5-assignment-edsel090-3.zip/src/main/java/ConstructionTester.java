import java.util.Scanner;

public class ConstructionTester
{
    public static void main(String[] args)
    {
       Scanner in = new Scanner(System.in);
      double lumberCost = 8;
      double windowCost = 11;
      double taxes, total;
      int boards, windows;

      System.out.println("Enter sale tax rate: ");
      taxes = in.nextDouble();
      System.out.println("Enter number of Boards: ");
      boards = in.nextInt();
      System.out.println("Enter number of windows");
      windows = in.nextInt();

      Construction dude = new Construction(lumberCost, windowCost, taxes);
      total = dude.lumberCost(boards)+dude.windowCost(windows);
      System.out.println("total: " + total);
      
      System.out.println("Grand total: "+ dude.grandTotal(total));
    }
}
